setwd("C:/Users/cardo/Desktop/TrabajosU/Formulaci�n")

## instalamos los paquetes correspondientes

library(readxl)
library(xml2)
library(dplyr)
library(rvest)

## importamos el excel

dataset <- read_excel("establecimientos de comercio ccg 2018.xls")

# revisamos el estado de la base de datos para asi mismo proceder a su modificaci�n

View(dataset)

# sacamos solamente las columnas que son de mi inter�s

View(dataset[c(11,13,16,33)])

# guardamos en una nueva variable la base de datos modificada

Tab1 <- dataset[c(33,11,13,16)]
View(Tab1)

# se le dan nuevos nombres a las columnas

nom <- c("Nombre","Direcci�n","Tel�fono","Correo electr�nico")
names(Tab1) <- nom

#

nf <- html("https://www.registraduria.gov.co/Luciana-Santiago-Maria-Jose-y-Juan-Jose-los-nombres-mas-populares-en-2019.html")
nf %>%
  html_nodes(".text-center:nth-child(20) td:nth-child(1) , p+ .text-center td:nth-child(1)") %>%
  html_text() -> nf
as.vector(nf) 
attach(Tab1)
names(Tab1)
head(Nombre)
options(max.print = 10000)


M <- "ROSA|VANESSA|YOLANDA|BLANCA|LILI|ROCIO|NANCY|JOHANA|CARMEN|FERNANDA|ANGELA|MARTA|MARTHA|MERCEDES|
LORENA|LINA|MARCELA|LEIDY|KAREN|PATRICIA|DAYANA|ERIKA|CATALINA|VALENTINA|SOPHY|NATALI|SANDRA|TATIANA|
OLGA|CAMILA|DANIELA|LAURA|MARIA|SOFIA|ALEJANDRA|ANDREA|ADRIANA|LUZ|FLOR|PAOLA|AMINTA|GUILLERMINA|ELSY|
VIVIANA|PAULA|CLAUDIA|ESPERANZA|CECILIA|JESSICA"
Tab2 <- Tab1[grep(M,as.character(Nombre)),]
View(Tab2)



c1 <- html("http://asojuntasgirardot.com/jac/juntas/01/barrios-comuna-1.html")
c1 %>%
  html_nodes(".active .active a") %>%
  html_text() -> c1
c1

c2 <- html("http://asojuntasgirardot.com/jac/juntas/01/barrios-comuna-2.html")
c2 %>%
  html_nodes(".active .active a") %>%
  html_text() -> c2
c2

c5 <- html("http://asojuntasgirardot.com/jac/juntas/01/barrios-comuna-5.html")
c5 %>%
  html_nodes(".active .active a") %>%
  html_text() -> c5
c5

com <- toupper(c(c1,c2,c5)) 
com

coms <- paste(com,collapse  = "|")
coms


Tab3 <- Tab2[grep("CENTRO",as.character(Direcci�n)),]
View(Tab3)




l <-as.vector(as.character(Tab2[,2]))  
l
View(l)
