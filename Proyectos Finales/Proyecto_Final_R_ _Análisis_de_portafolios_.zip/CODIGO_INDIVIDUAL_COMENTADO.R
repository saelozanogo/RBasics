
#-------------------------------------------------#        
#- PROYECTO ANALISIS DE PORTAFOLIOS DE INVERSION -#
#-------------------------------------------------#

rm(list=ls()) #Limpia el entorno global
options(scipen = 999) #para mismo formato de decimales

library(readxl) #ExceL
library(PortfolioAnalytics) #Analisis Grupal
library(quantmod)#MODELACION DATA
library(fPortfolio) #Analisis individual 
library(tseries) #Extraccion de data individual 
library(ROI) #METODO DE BALANCEO RETORNO
library(ROI.plugin.glpk) #PLUGIN PARA MAXIMIZAR RETORNOS
library(IntroCompFinR) 

precios <- NULL
menu_excel <- read_excel(file.choose(),sheet = "Menu",col_names = FALSE) #Abre ruta y archivo excel

#TOMA LOS VALORES QUE SE INDICAN DE LA HOJA DE CALCULO MENU
ticker_indice <- as.character(menu_excel[2,5])
ticker_a1 <- as.character(menu_excel[8,5])
ticker_a2 <- as.character(menu_excel[11,5])
ticker_a3 <- as.character(menu_excel[14,5])
ticker_a4 <- as.character(menu_excel[17,5])


tickers <- c(ticker_a1,ticker_a2,ticker_a3,ticker_a4) #CREA EL VECTOR A MANEJAR


for (i in tickers) {
  precios <- cbind(precios,getSymbols(i,src = "yahoo",from="2008-01-04",to="2020-04-30",periodicity="daily",auto.assign = FALSE)[,c(4)])
}

#INDICE USADO
par(mfcol=c(1,1))
Indice<- get.hist.quote(instrument = ticker_indice, start=as.Date("2008-01-04"), end=as.Date("2020-04-30"), quote = "AdjClose")
plot(Indice, col="lightblue", xlab="Fecha", ylab="$ Cierre"); title(main="Evoluci�n Indice") #evolucion x a�os

#RETORNOS DEL INDICE
RetornoIndice<-diff(log(Indice))
head(RetornoIndice,10)
plot(RetornoIndice, main=" ", col="lightblue", xlab="Fecha", ylab="Rendimientos")
title(main="Rendimientos del Indice")


#--------------------------------------
#RETORNOS DEL PORTAFOLIO 
retornos <- na.omit(ROC(precios))#na omite los dias no transados para evitar errores, ROC calcula rendimientos
encabezados <- c(ticker_a1,ticker_a2,ticker_a3,ticker_a4) #rotulos de la tabla
colnames(retornos)<-encabezados #Cambio nombre de la tabla "sus rotulos"

#Graficas de evolucion y precios de los activos
precios_time_series <- as.timeSeries(precios)
par(mfcol=c(2,2))
seriesPlot(precios_time_series) #Evoluci�n
returnPlot(precios_time_series) #Retornos

#RATIO DE SHARPE
SharpeRatio(R=retornos,Rf=0,FUN = "StdDev") #Entre mas grande mas atractiva

#OPTIMIZAR PORTAFOLIO
portafolio_inicial <-portfolio.spec(assets = colnames(retornos)) #Los activos de mi portafolio
portafolio_inicial <- add.constraint(portfolio = portafolio_inicial,type = "weight_sum",min_sum=1,max_sum=1)
portafolio_inicial <- add.constraint(portfolio = portafolio_inicial,type = "box",min=c(0.2,0.2,-1,-1),max=c(0.2,0.2,2,2))           

maximo_retornos <- add.objective(portfolio = portafolio_inicial,type = "return",name="mean") #MAXIMIZAR RETORNOS
maximo_optimizado <- optimize.portfolio(R = retornos,portfolio = maximo_retornos, optimize_method = "ROI",maxSR=TRUE,trace = TRUE) #PESOS RELATIVOS

par(mfcol=c(1,1))
chart.Weights(maximo_optimizado) #Grafico Pesos relativos

#matriz de covarianzas
covarianza <- round(cov(retornos),4) #RELACI�N ENTRE LOS ACTIVOS 


#PORTAFOLIO 
media_rendimientos <- colMeans(retornos) #promedio de los rendimientos de cada activo
retorno_portafolio <- media_rendimientos%*%maximo_optimizado[["weights"]] #Retorno esperado por el portafolio 
retorno_portafolio #DIARIOS

#FINAL EFICIENTE
portafolio_eficiente <- efficient.portfolio(media_rendimientos,covarianza,retorno_portafolio,shorts = TRUE)

maximo_optimizado[["weights"]] #A 
portafolio_eficiente[["weights"]] #D
