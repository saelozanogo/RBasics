install.packages("openxlsx")
install.packages("readxl");
install.packages("ggplot2")
library(TSA)
library(readxl)
library(ggplot2)
ruta<-BASE_DE_DATOS_FEMINICIDIO
ruta
View(ruta)
datos<-ruta[,c("Fecha","Edad de la v�ctima","G�nero del victimario","Edad victimario","Relaci�n con la victima","Departamento","�Hubo agresi�n previa?","M�vil","Agresi�n que caus� la muerte","Sentencia")]
View(datos)

plot(datos$Fecha,datos$`Edad de la v�ctima`) # plot de edad de muerte de las victimas los �ltimos a�os


## Cantidad de mujeres afectadas y causas de su muerte

ag <- unique(datos$`Agresi�n que caus� la muerte`)
ag

oo <- c()
for (i in ag) {
  y <- length(grep(i,as.character(datos$`Agresi�n que caus� la muerte`)))
  oo <- c(oo,y)
}
oo
xx <- data.frame("Causa de la muerte" = ag,"Mujeres afectadas" = oo)
View(xx)

ggplot(xx, aes(y=Mujeres.afectadas,x=Causa.de.la.muerte)) + 
  geom_bar(stat = "identity", width = 0.7, fill="pink") + 
  labs(title = "Feminicidios",
       subtitle = "Mujeres afectadas Vs Causa de la muerte",
       caption = "Fuente: BADAC")+
  theme(axis.text.x = element_text(angle = 20, vjust = 0.5))


## Cantidad de mujeres afectadas por departamento

bg <- unique(datos$Departamento)
bg

oo <- c()
for (i in bg) {
  y <- length(grep(i,as.character(datos$Departamento)))
  oo <- c(oo,y)
}
oo
xy <- data.frame("Departamento" = bg,"Mujeres afectadas" = oo)
View(xy)

ggplot(xy, aes(y=Mujeres.afectadas,x=Departamento)) + 
  geom_bar(stat = "identity", width = 0.7, fill="green") + 
  labs(title = "Feminicidios 2",
       subtitle = "Mujeres afectadas Vs Departamento",
       caption = "Fuente: BADAC")+
  theme(axis.text.x = element_text(angle = 70, vjust = 0.5))


## Relaci�n  de Victima con victimario

cg <- unique(datos$`Relaci�n con la victima`)
cg

oo <- c()
for (i in cg) {
  y <- length(grep(i,as.character(datos$`Relaci�n con la victima`)))
  oo <- c(oo,y)
}
oo
xz <- data.frame("Relaci�n" = cg,"Mujeres afectadas" = oo)
View(xz)

ggplot(xz, aes(y=Mujeres.afectadas,x=Relaci�n)) + 
  geom_bar(stat = "identity", width = 0.7, fill="blue") + 
  labs(title = "Feminicidios 3",
       subtitle = "Mujeres afectadas Vs Relaci�n con victimario",
       caption = "Fuente: BADAC")+
  theme(axis.text.x = element_text(angle = 70, vjust = 0.5))

## Alerta agresi�n previa
dg<-unique(datos$`�Hubo agresi�n previa?`)
dg
oo<-c()
for (i in dg) {
  z<-length(grep(i,as.character(datos$`�Hubo agresi�n previa?`)))
  oo<-c(oo,y)
}
oo
zz<-data.frame("Agres�on previa"=dg, "Mujeres afectadas"=oo)
View(zz)
